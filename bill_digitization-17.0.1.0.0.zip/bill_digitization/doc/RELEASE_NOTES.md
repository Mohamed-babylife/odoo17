## Module <bill_digitization>
#### 18.04.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Bill Digitization
