# -*- coding: utf-8 -*-

from . import base_module_update
