{
    'name': 'Compact Invoice Template',
    'version': '18.0.1.0.0',
    'depends': ['base', 'account', 'web'],
    "author": "GRAEF - Productivity Tools",
    'category': 'Accounting/Invoicing',
    'summary': 'Enhanced invoice layout with optimized space utilization and comprehensive tax information',
    'description': """
    Transform your business invoices with a professionally designed template that improves readability and information hierarchy.
    
    Key Features:
    * Optimized layout with efficient space utilization
    * Strategic positioning of company and customer information
    * Intelligent delivery address placement
    * Detailed tax code integration per line item
    * Comprehensive tax code summary
    * Professional document formatting
    
    Benefits:
    * Improved document clarity
    * Better customer experience
    * Enhanced tax compliance
    * Professional brand presentation
    """,
    'data': [
        'views/report_templates.xml',
        'data/report_layout.xml',
    ],
    "price": 0,
    "currency": "EUR",
    "installable": True,
    "application": False,
    "license": "OPL-1",
    "images": ["static/description/invoice_template_compact_cover.png"],
}