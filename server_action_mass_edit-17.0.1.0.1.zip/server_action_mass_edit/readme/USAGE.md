- *Go for Mass Editing*: select the records which you want to modify and
  click on *Action* to open mass editing popup.

![Action](../static/description/mass_editing-item_tree.png)

- Select *Set / Remove* action and write down the value to set or remove
  the value for the given field.

![Wizard Form](../static/description/mass_editing-wizard_form.png)

- This way you can set / remove the values of the fields.

![Wizard Result](../static/description/mass_editing-item_tree-result.png)
