# -*- coding: utf-8 -*-
# Part of Creyox Technologies
from . import res_users
from . import product_template
from . import product_category
