## Module <inter_company_synchronization>

#### 05.08.2024
#### Version 17.0.1.0.0
#### ADD
- Initial Commit for Inter Company Sale and Purchase Synchronization

#### 27.08.2024
#### Version 17.0.1.0.1
##### UPDT
- Bug Fix - Resolved the error while confirming quotation