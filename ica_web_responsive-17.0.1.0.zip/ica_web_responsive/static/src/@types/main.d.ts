declare module "@odoo/owl" {
    export * from "@odoo/owl/dist/types/owl"
}
