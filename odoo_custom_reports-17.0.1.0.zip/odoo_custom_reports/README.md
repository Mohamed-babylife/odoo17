ODOO CUSTOM REPORTS.
---------------------

This module installs custom Reports to your Odoo.
You can generate both PDF and Excel (xlsx) reports.

The reports are generated from a wizard, where you can select a range of dates.

Product Invoice Reports
--------------------------------------

These are reports for products in invoices between a range of dates. Helps you to know how much your invoices are worth, and the products in those invoices.

Another Report
--------------------------------------

These are reports for products in invoices between a range of dates. Helps you to know how much your invoices are worth, and the products in those invoices.

