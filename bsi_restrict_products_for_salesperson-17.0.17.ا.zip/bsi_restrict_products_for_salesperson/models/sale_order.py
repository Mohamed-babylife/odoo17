# -*- coding: utf-8 -*-
#################################################################################
#
#    Odoo, Open Source Management Solution
#    Copyright (C) 2023-today Botspot Infoware Pvt. Ltd. <www.botspotinfoware.com>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#################################################################################
from odoo import api, fields, models
from odoo.exceptions import ValidationError


class SaleOrder(models.Model):
    _inherit = "sale.order"

    @api.constrains("user_id", "order_line")
    def check_salesperson(self):
        cv = []
        if self.user_id:
            if self.user_id.restrict_product_ids:
                for record in self.order_line:
                    if record.product_id.id in self.user_id.restrict_product_ids.ids:
                        cv.append(record.product_id.name)
                if cv != []:
                    raise ValidationError(
                        "* You can not create an order for restricted products like,  :- \n"
                        + "\n".join(map(str, cv))
                        + "\n\n * Contact higher authority to access for restricted products."
                    )
