# -*- coding: utf-8 -*-
# Powered by Kanak Infosystems LLP.
# © 2020 Kanak Infosystems LLP. (<https://www.kanakinfosystems.com>).

{
    'name': 'Purchase Quotation Multi Cancellation',
    'version': '17.0.1.0',
    'license': 'OPL-1',
    'depends': ['purchase'],
    'category': 'Inventory/Purchase',
    'website': 'https://www.kanakinfosystems.com',
    'author': 'Kanak Infosystems LLP.',
    'summary': 'This module is used to cancel multiple purchase orders at the same time. | Purchase Quotation | Multi Cancellation | Cancel Purchase Quotations | Request for Quotation (RFQ) | Cancel RFQ | Purchase Order | Purchase Order Cancellation | Cancelation Process | Odoo Purchase Cancelation Module',
    'description': """
    This module is used to cancel multiple purchase orders at the same time.
    """,
    'data': ['data/data.xml'],
    'images': ['static/description/banner.jpg'],
    'price': 0,
    'currency': 'EUR',
    'sequence': 1,
    'installable': True,
    'live_test_url': 'https://www.youtube.com/watch?v=ZyxciNuDZRg',
}
