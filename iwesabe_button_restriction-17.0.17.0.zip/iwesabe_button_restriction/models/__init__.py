# -*- coding: utf-8 -*-

from . import restrict_button
from . import ir_actions_act_window
