## Module <sales_order_double_approval>

#### 22.08.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Sales Order Double Approval
