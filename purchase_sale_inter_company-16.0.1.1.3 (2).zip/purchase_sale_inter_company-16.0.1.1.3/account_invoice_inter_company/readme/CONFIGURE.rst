To configure this module, you need to go to the menu *Settings > General Settings*, go to the tab *Companies / Inter Company OCA features*

You now have access to other checks *Common Product Catalog*, *Generate Intercompany Invoices* and *Invoice Auto Validation*.

To customize products sharing don't hesitate to override `_compute_share_product()` in `res.company` model.
