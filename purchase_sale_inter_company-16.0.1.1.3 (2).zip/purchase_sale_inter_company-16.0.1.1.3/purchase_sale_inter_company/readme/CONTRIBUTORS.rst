* Odoo S.A. (original module `inter_company_rules`)
* Andrea Stirpe <a.stirpe@onestein.nl>
* Adria Gil Sorribes <adria.gil@forgeflow.com>
* Christopher Ormaza <chris.ormaza@forgeflow.com>
* `Akretion <https://www.akretion.com>`:

  * Chafique Delli <chafique.delli@akretion.com>
  * Alexis de Lattre <alexis.delattre@akretion.com>
  * David Beal <david.beal@akretion.com>
* `Tecnativa <https://www.tecnativa.com>`:

  * Jairo Llopis
  * David Vidal
  * Pedro M. Baeza
* `Camptocamp <https://www.camptocamp.com>`:

  * Maksym Yankin <maksym.yankin@camptocamp.com>
