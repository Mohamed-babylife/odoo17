If you want also to have different warehouses for your sales orders you can install `stock` and then `purchase_sale_stock_inter_company` will be auto installed.
