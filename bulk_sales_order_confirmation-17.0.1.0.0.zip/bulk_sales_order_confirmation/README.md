---------------------------------
Bulk Confirm Quotations
---------------------------------


This module add new method on sale order:

* This app allows you to confirm multiple sales order in bulk

**Table of contents**

Installation:
-------------

There are two depended module sale and sale_management for accessing the needed for the actions.

Usage:
------

In the sales order, you can select multiple Quotation/Quotation Sent to convert into confirm in bulk.

Authors:
--------
* Manish Kumar Bohra

Developer:
----------
* Manish Kumar Bohra <manishkumarbohra@outlook.com>

