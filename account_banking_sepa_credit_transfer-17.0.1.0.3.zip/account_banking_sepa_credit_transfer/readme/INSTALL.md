This module depends on : \* account_banking_pain_base

This module is part of the OCA/bank-payment suite.
