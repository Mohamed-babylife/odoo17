## Module <invoice_format_editor>

#### 03.11.2023
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Invoice Format Editor

#### 02.04.2024
#### Version 17.0.1.1.0
##### UPDT
- Bug Fix-Resolved the attribute error, updated the report templates